package com.namastevk.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) speech = SpeechRecognizer.createSpeechRecognizer(this)
        speak("Namaste. Main V K hoon. Version two point zero taiyar hai.")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 32, 26, 28)
            setBackgroundColor(0xFF050B16.toInt())
        }
        val title = TextView(this).apply {
            text = "NAMASTE V K"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFF61DFFF.toInt())
        }
        val version = TextView(this).apply {
            text = "VERSION 2.0 • PERSONAL AI"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFF9DBCD0.toInt())
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 96f
            gravity = Gravity.CENTER
            setTextColor(0xFF39D5FF.toInt())
            setPadding(0, 18, 0, 18)
        }
        status = TextView(this).apply {
            text = "READY • Tap to speak"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }
        transcript = TextView(this).apply {
            text = "Try: search latest welding technology, open YouTube, open Chrome, open WhatsApp"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFB6C9D8.toInt())
            setPadding(8, 18, 8, 22)
        }
        val mic = Button(this).apply {
            text = "🎙  TALK TO V K"
            textSize = 18f
            setOnClickListener { listen() }
        }
        val search = Button(this).apply {
            text = "🔎  AI / WEB SEARCH"
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=AI+assistant"))) }
        }
        val wakeInfo = Button(this).apply {
            text = "VOICE WAKE-UP SETTINGS"
            setOnClickListener {
                val msg = "Wake phrase V K aur aapki personal voice identity ke liye dedicated on-device wake-word aur speaker-verification model chahiye. Yeh starter version abhi always-on listening nahi karta."
                transcript.text = msg
                speak(msg)
            }
        }
        root.addView(title); root.addView(version); root.addView(orb)
        root.addView(status); root.addView(transcript); root.addView(mic)
        root.addView(search); root.addView(wakeInfo)
        setContentView(root)
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41); return
        }
        if (speech == null) {
            Toast.makeText(this, "Speech recognition is not available on this phone.", Toast.LENGTH_LONG).show(); return
        }
        status.text = "LISTENING..."
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Namaste V K ko command dein")
        }
        try {
            speech?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "I'M LISTENING..." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "THINKING..." }
                override fun onError(error: Int) { status.text = "READY"; transcript.text = "Awaaz samajh nahi aayi. Dobara try karein." }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    transcript.text = "You: $words"
                    handleCommand(words)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speech?.startListening(intent)
        } catch (e: Exception) {
            status.text = "Could not start listening"
            transcript.text = e.localizedMessage ?: "Speech error"
        }
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT)
        when {
            c.startsWith("search ") || c.startsWith("google ") || c.startsWith("खोजो ") || c.startsWith("सर्च ") -> {
                val query = raw.replaceFirst(Regex("(?i)^(search|google|खोजो|सर्च)\\\\s*"), "").trim()
                if (query.isNotBlank()) {
                    speak("Aapki search khol raha hoon.")
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
                } else speak("Kya search karna hai, batayein.")
            }
            c.contains("youtube") || c.contains("यूट्यूब") -> openPackage("com.google.android.youtube", "YouTube khol raha hoon.")
            c.contains("chrome") || c.contains("क्रोम") -> openPackage("com.android.chrome", "Chrome khol raha hoon.")
            c.contains("whatsapp") || c.contains("व्हाट्सएप") -> openPackage("com.whatsapp", "WhatsApp khol raha hoon.")
            c.contains("google") || c.contains("गूगल") -> openPackage("com.google.android.googlequicksearchbox", "Google khol raha hoon.")
            c.contains("call") || c.contains("कॉल") || c.contains("फोन") -> {
                speak("Phone dialer khol raha hoon. Call karne se pehle number confirm karein.")
                startActivity(Intent(Intent.ACTION_DIAL))
            }
            c.contains("hello") || c.contains("नमस्ते") -> speak("Namaste! Main V K hoon. Main aapki madad ke liye taiyar hoon.")
            else -> speak("Aapne kaha: $raw. Is sawal ka smart AI jawab dene ke liye secure AI service connect karni hogi.")
        }
        status.text = "READY"
    }

    private fun openPackage(pkg: String, spoken: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) { speak(spoken); startActivity(launch) }
        else { speak("Yeh app phone mein installed nahi mil raha."); transcript.append("\\nApp not found: $pkg") }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "namaste-vk")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale("hi", "IN")
            tts?.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        speech?.destroy(); tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
